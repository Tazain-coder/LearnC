#include<stdio.h>
int main()
{
    int i,x[10];
    for (i=0; i<10; i++)
    {
        scanf("%d",&x[i]);
    }
    printf("%d\n",x[i]);

    return 0;
}
