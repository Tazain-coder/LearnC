#include <stdio.h>
int main()
{
    int number;
    printf("Octal number = ");
    scanf("%o",&number);

    printf("Decimal number = %d",number);
    getch();

    return 0;
}

