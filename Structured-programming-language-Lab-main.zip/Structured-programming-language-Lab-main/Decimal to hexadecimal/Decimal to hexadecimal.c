#include <stdio.h>
int main()
{
    int number;
    printf("Decimal number = ");
    scanf("%d",&number);

    printf("Hexadecimal number = %x",number);
    getch();

    return 0;
}

