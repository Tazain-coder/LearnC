#include<stdio.h>
int main()
{

    int x=011,i,y;

    for (i=0; i<x; i+=3)
    {
        printf("start\n");
    }
     scanf("%d",&y);
     if (y<0)

     {
         printf("End");
     }

}

