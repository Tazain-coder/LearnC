/// 2016  1c

#include<stdio.h>
void main()
{
    char arr[7] = "Network";
    printf("%s",arr);
}
