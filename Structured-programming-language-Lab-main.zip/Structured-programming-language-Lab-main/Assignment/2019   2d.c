#include<stdio.h>
int main()
{
    int i=1;
    switch(i)
    {
        printf("Hello\n");
        case 1:
            printf("Hi\n");
            break;
        case 2:
            printf("\nBye\n");
            break;
    }
    return 0;
}
