#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    printf("%i\n",atoi("245"));
    printf("%i\n",atoi("100") + 25);
    printf("%i\n",atoi("13x5"));

    return 0;
}
