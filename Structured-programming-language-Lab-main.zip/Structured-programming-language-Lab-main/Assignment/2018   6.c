#include<stdio.h>
int main()
{
    int x=5;
    printf("%d",square(x));
}
