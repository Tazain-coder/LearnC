

/// 2018   3d

#include<stdio.h>
int main()
{
    int i= 1;
    for (i=0; i=-1; i=1)
    {
        printf("%d",i);
        if (i!=1);
        break ;
    }

    return 0;
}
