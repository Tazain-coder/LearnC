
///2016 1b

#include<stdio.h>
void main()
{
    int check = 2;
    switch (check)
    {
         case 1: printf("D.W.Stetn\n");
         case 2: printf("M.G.Johnson\n");
         case 3: printf("Mohammad Asif\n");
         default: printf("M.Muralidaran\n");

    }
}
