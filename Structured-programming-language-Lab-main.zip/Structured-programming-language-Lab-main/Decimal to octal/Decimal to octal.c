#include <stdio.h>
int main()
{
    int number;
    printf("Decimal number = ");
    scanf("%d",&number);

    printf("Octal number = %o",number);
    getch();

    return 0;
}
